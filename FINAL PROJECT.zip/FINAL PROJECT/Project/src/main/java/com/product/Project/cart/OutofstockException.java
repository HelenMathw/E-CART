package com.product.Project.cart;

public class OutofstockException extends Exception {
	 OutofstockException(String msg)
	 {
		 super(msg);
	 }
}

package com.product.Project.customer;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class customerService {
	@Autowired
	private customerRepository customer_repo;
	public List<customer> listcustomer()
	{
		return(List<customer>)customer_repo.findAll();
	}
	public void savecustomer(customer customer)
	{
		customer_repo.save(customer);
	} 
	public customer get(Integer id) throws customerNotFoundException
	{
		 Optional<customer> result=customer_repo.findById(id);
		 if(result.isPresent()) {
			 return result.get();
		 }
		 else
		 {
			 throw new customerNotFoundException("customer not present");
		 }
	}
	public customer Check(String email) throws customerNotFoundException
	{
		System.out.println(""+email); 
		Optional<customer> customer_result=customer_repo.findBycustomerEmail(email);
		 if(customer_result.isPresent()) {
			 return customer_result.get();
		 }
		 else
		 {
			 throw new customerNotFoundException("customer not present");
		 }
	}

	public void customerdelete(Integer id) throws customerNotFoundException {
		customer_repo.deleteById(id);
	}
	
}

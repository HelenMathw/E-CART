package com.product.Project.customer;

public class customerNotFoundException extends Exception {
	public customerNotFoundException(String msg)
	{
		super(msg);
	}

}

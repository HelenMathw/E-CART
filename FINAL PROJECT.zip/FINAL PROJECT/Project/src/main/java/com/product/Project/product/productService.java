package com.product.Project.product;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

@Service
public class productService {
	@Autowired
	private productRepository repo;
	public List<products> Listall()
	{
		return(List<products>)repo.findAll();
	}
	public void save(products product)
	{
		repo.save(product);
	} 
	public products get(Integer id) throws UsernotFoundException
	{
		 Optional<products> result=repo.findById(id);
		 if(result.isPresent()) {
			 return result.get();
		 }
		 else
		 {
			 throw new UsernotFoundException("User not present");
		 }
	}
	public void delete(Integer id) throws UsernotFoundException {
		repo.deleteById(id);
	
	}

}

package com.product.Project.seller;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="seller")
public class seller {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="seller_id")
	private int sellerId;
	
	@Column(nullable=false,unique=true)
	private String sellerEmail;
	@Column(length=15,nullable=false)
	private String sellerPassword;
	@Column(length=35,nullable=false,name="seller_first_name")
	private String sellerFirstname;
	@Column(length=15,nullable=false,name="seller_last_name")
	private String sellerLastname;
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getSellerEmail() {
		return sellerEmail;
	}
	public void setSellerEmail(String sellerEmail) {
		this.sellerEmail = sellerEmail;
	}
	public String getSellerPassword() {
		return sellerPassword;
	}
	public void setSellerPassword(String sellerPassword) {
		this.sellerPassword = sellerPassword;
	}
	public String getSellerFirstname() {
		return sellerFirstname;
	}
	public void setSellerFirstname(String sellerFirstname) {
		this.sellerFirstname = sellerFirstname;
	}
	public String getSellerLastname() {
		return sellerLastname;
	}
	public void setSellerLastname(String sellerLastname) {
		this.sellerLastname = sellerLastname;
	}
	
	
}

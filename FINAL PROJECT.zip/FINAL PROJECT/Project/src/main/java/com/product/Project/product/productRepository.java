package com.product.Project.product;

import org.springframework.data.repository.CrudRepository;

public interface productRepository extends CrudRepository<products,Integer> {

}

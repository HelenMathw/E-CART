package com.product.Project.customer;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

public interface customerRepository extends CrudRepository<customer,Integer> {
	Optional<customer> findBycustomerEmail(String Email);

}

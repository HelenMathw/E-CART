package com.product.Project.seller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.product.Project.customer.customerNotFoundException;
import com.product.Project.customer.customer;
@Controller
public class sellerController {
	
	@Autowired
	private sellerService seller_service;
	
	@GetMapping("/Seller_LoginPage")
	public String showseller_page(Model model)
	{
		model.addAttribute("seller",new seller());
		model.addAttribute("pageTitle","Seller login");
		return"sellerLogin";
	}
	@GetMapping("/seller_signup")
	public String shownewseller_signupform(Model model)
	{
		model.addAttribute("seller",new seller());
		model.addAttribute("pageTitle","Seller signup");
		return"sellerSignup";
	}
	@PostMapping("/seller/save")
	public String saveseller(seller seller, RedirectAttributes ra)
	{
		seller_service.save(seller);
		ra.addFlashAttribute("message","seller saved succesfully");
		return "sellerLogin";
	}
	@PostMapping("/seller/login")
	public String checkseller(seller Seller,RedirectAttributes ra,Model model)
	{
		try {
		System.out.println(Seller.getSellerEmail());
		seller SELLER =seller_service.Check(Seller.getSellerEmail());
		if(SELLER.getSellerPassword().equals(Seller.getSellerPassword()))
		{
			return"sellerHome";
			
		}
		else
		{
			model.addAttribute("seller",new seller());
			model.addAttribute("pageTitle","Incorrect password");
			return"sellerLogin";
		}
	}
	catch(customerNotFoundException e)
	{
		model.addAttribute("seller",new seller());
		System.out.println("Inside catch");
		model.addAttribute("pageTitle","New Seller? Enter details");
		return"sellerSignup";
	}
	}
}

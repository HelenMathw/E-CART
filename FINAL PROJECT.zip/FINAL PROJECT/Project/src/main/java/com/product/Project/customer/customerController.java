package com.product.Project.customer;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class customerController {
	@Autowired
	private customerService customer_service;
	@GetMapping("/customer_LoginPage")
	public String showcustomerLogin(Model model)
	{
		model.addAttribute("Customer",new customer());
		model.addAttribute("pageTitle","Customer Login");
		return"customerLogin";
	}
	@GetMapping("/allcustomer")
	public String showcustomerlist(Model model) {
		
		List<customer> listcustomer= customer_service.listcustomer();
		model.addAttribute("listcustomer",listcustomer);
		return "customerList";
	}
	@GetMapping("/newcustomer")
	public String showNewcustomerForm(Model model)
	{
		model.addAttribute("customer",new customer());
		model.addAttribute("pageTitle","New Customer");
		return"customerSignup";
	}
	@PostMapping("/customer/save")
	public String savecustomer(customer customer,RedirectAttributes cra)
	{
		customer_service.savecustomer(customer);
		cra.addFlashAttribute("message","The customer has been saved successfully");
		return "redirect:/customer_LoginPage";
	}
	
	@GetMapping("/customer/edit/{customerId}")
	public String showcustomerEditForm(@PathVariable("customerId") Integer id,Model model,RedirectAttributes cra)
	{
		try {
		 customer customer=customer_service.get(id);
		 model.addAttribute("customer", customer);
		 model.addAttribute("pageTitle","EDIT Customer (ID:"+id+")");
		 return "customerSignup";
		}
		catch(customerNotFoundException e)
		{
			cra.addFlashAttribute("message",e.getMessage());
			return "redirect:/allcustomer";
		}
	}
		@GetMapping("/customer/delete/{customerId}")
		public String deletecustomer (@PathVariable("customerId") Integer id,RedirectAttributes ra)
		{
			try {
				customer_service.customerdelete(id);
		
			}
			catch(customerNotFoundException e)
			{
				ra.addFlashAttribute("message",e.getMessage());
				
			}
			ra.addFlashAttribute("message","The customer has been Deleted successfully");
			return "redirect:/allcustomer";
		}
		@PostMapping("/customer/login")
		public String checkcustomer(customer customer,RedirectAttributes ra,Model model)
		{
			try {
			System.out.println(customer.getCustomerEmail());
			customer customerCheck =customer_service.Check(customer.getCustomerEmail());
			if(customerCheck.getCustomerPassword().equals(customer.getCustomerPassword()))
			{
				model.addAttribute("customer",customerCheck);
				 model.addAttribute("customerId", customerCheck.getCustomerId());
				return"customerHome";
			}
			else
			{
				model.addAttribute("Customer",new customer());
				model.addAttribute("pageTitle","Incorrect password");
				return"customerLogin";
			}
		}
		catch(customerNotFoundException e)
		{
			model.addAttribute("customer",new customer());
			System.out.println("Inside catch");
			model.addAttribute("pageTitle","New customer? Enter details");
			return"customerSignup";
		}
		}
	

}

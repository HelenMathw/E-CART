package com.product.Project.cart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.product.Project.customer.customerNotFoundException;
import com.product.Project.customer.customer;
import com.product.Project.customer.customerService;
import com.product.Project.product.UsernotFoundException;
import com.product.Project.product.products;
import com.product.Project.product.productService;

@Controller
public class CartController {
	@Autowired
	private CartService cart_service;
	@Autowired
	private productService product_service;
	@Autowired
	private customerService customer_service;
	@GetMapping("/cartform")
	public String showCartForm(Model model)
	{
		model.addAttribute("Cart",new Cart());
		model.addAttribute("pageTitle","YOUR CART");
		return"addTocart";
	}
	@GetMapping("/products/cart/{customerId}/{productId}")
	public String showaddcartForm(@PathVariable("customerId") Integer customerId, @PathVariable("productId") Integer productId,Model model,RedirectAttributes ra)
	{
		try {
		 products product=product_service.get(productId);
		 customer customer=customer_service.get(customerId);
		 Cart cart=new Cart();
		 cart.setProduct(product);
		 cart.setCustomer(customer);
		 //model.addAttribute("customerId", customerId);
		 model.addAttribute("cart", cart);
		 model.addAttribute("pageTitle","YOUR CART");
		 return "addTocart";
		}
		catch(UsernotFoundException e)
		{
			ra.addFlashAttribute("message",e.getMessage());
			return "redirect:/allproduct";
		}
		catch (customerNotFoundException e) {
						e.printStackTrace();
						ra.addFlashAttribute("message",e.getMessage());
						return "redirect:/allproduct";
		}
	}
	@PostMapping("/check")
	public String checkavailability(Cart Cart, RedirectAttributes cart_ra,Model model) throws OutofstockException
	{
		try {
			 customer customer=cart_service.checkcustomer(Cart.getCustomer().getCustomerId());
			 products product =cart_service.checkproduct(Cart.getProduct().getId());
			 if(product.getQuantity()>=Cart.getCartQuantity())
			 { 
			 	Cart.setCartPrice(product.getPrice()*Cart.getCartQuantity());
			 	model.addAttribute("customerId", Cart.getCustomer().getCustomerId());
			 	 model.addAttribute("Cart",Cart);
			   return "cartConfirm";
			 }
			 else
			 {
				 cart_ra.addFlashAttribute("message","Product out of stock");
				 return "redirect:/allproduct";
			 }
			}
			catch(customerNotFoundException e)
			{
				model.addAttribute("customer",new customer());
				model.addAttribute("pageTitle","New customer? Enter details");
				return "customerSignup";
			}
		catch(UsernotFoundException ea)
		{
			cart_ra.addFlashAttribute("message",ea.getMessage());
			return "redirect:/allproduct";
		}
		}
	
	@PostMapping("/confirmCart")
	public String confirmCart(@ModelAttribute("cart")Cart cart,RedirectAttributes ra,Model model)
	{
		cart_service.savecart(cart);
		Integer id=cart.getCustomer().getCustomerId();
		return "redirect:/cartcustomer/"+id;
	}
	@GetMapping("/cartcustomer/{customerId}")
	public String showcustomercart(@PathVariable("customerId") Integer customerId,Model model,RedirectAttributes ra)
	{
		try {
			customer customerCheck=customer_service.get(customerId);
			List<Cart> listCart= cart_service.Listall(customerId);
			model.addAttribute("listCart",listCart);
		}
		catch (customerNotFoundException e) {
			e.printStackTrace();
		}
		
		return"cartCustomerpage";
	}
	@GetMapping("/cart/edit/{id}")
	public String showEditcartform(@PathVariable("id") Integer id,Model model,RedirectAttributes ra)
	{
		try {
		 Cart cart=cart_service.get(id);
		 model.addAttribute("cart", cart);
		 model.addAttribute("pageTitle","Edit cart");
		 return "addTocart";
		}
		catch (OutofstockException e) {
			e.printStackTrace();
			return"firstPage";
		}
	}
	@GetMapping("/cart/delete/{id}")
	public String showDeletecartform(@PathVariable("id") Integer id,Model model,RedirectAttributes ra) throws OutofstockException
	{
		
		 Cart cart= cart_service.get(id);
		 Integer deleteId=cart.getCustomer().getCustomerId();
		cart_service.delete(id);
			return "redirect:/cartcustomer/"+deleteId;
	}
}
	
	/*@PostMapping("/confirmorder")
	public String confirmorder(@ModelAttribute("Cart") Cart Cart ,RedirectAttributes cart_ra)
	{
		 products product=Cart.getProduct();
		 product.setQuantity(product.getQuantity()-Cart.getCartQuantity());
		 product_service.save(product);
		 cart_service.saveorder(Cart);
		 return"confirmedpage";
	}*/
	


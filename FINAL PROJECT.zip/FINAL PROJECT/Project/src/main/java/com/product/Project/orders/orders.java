package com.product.Project.orders;

import com.product.Project.customer.customer;
import com.product.Project.product.products;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
@Entity
public class orders {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
   private int order_id;
	
	private  int order_quantity;
	private int order_price;

	
	public int getOrder_price() {
		return order_price;
	}


	public void setOrder_price(int order_price) {
		this.order_price = order_price;
	}

	@ManyToOne
    @JoinColumn(name="id", nullable=false)
	private products product;
	
	@OneToOne
    @JoinColumn(name="customer_id", nullable=false)
	private customer customer;
	
		
	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public  int getOrder_quantity() {
		return order_quantity;
	}

	public void setOrder_quantity(int order_quantity) {
		this.order_quantity = order_quantity;
	}

	public  products getProduct() {
		return product;
	}

	public void setProduct(products product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Cart [order_id=" + order_id + ", order_quantity=" + order_quantity + ", product=" + product
				+ ", customer=" + customer + "]";
	}

	public customer getcustomer() {
		return customer;
	}

	public void setcustomer(customer customer) {
		customer = customer;
	} 

}



package com.product.Project.orders;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.product.Project.cart.Cart;
import com.product.Project.cart.CartService;
import com.product.Project.product.productService;
import com.product.Project.product.products;
@Controller
public class orderController {
	
	@Autowired
	private CartService cartService;
	@Autowired
	private productService product_service;
	
	@GetMapping("/confirmorder/{id}")
	public String confirmorder(@PathVariable("id") Integer customerId)
	{
		List<Cart> listCart= cartService.Listall(customerId);
		for (Cart cart : listCart) {
	        products product = cart.getProduct();
	        product.setQuantity(product.getQuantity() - cart.getCartQuantity());
	        product_service.save(product);
	    }
		 return"confirmedpage";
	}

}

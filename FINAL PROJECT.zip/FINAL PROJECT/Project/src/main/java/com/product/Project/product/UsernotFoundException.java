package com.product.Project.product;

public class UsernotFoundException extends Exception {
	public UsernotFoundException(String msg)
	{
		super(msg);
	}

}

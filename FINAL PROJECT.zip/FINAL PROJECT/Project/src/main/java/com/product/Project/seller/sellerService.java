package com.product.Project.seller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.Project.customer.customerNotFoundException;
@Service
public class sellerService {

@Autowired
private sellerRepository sr_repo;

public void save(seller seller)
{
	sr_repo.save(seller);
}

public seller Check(String email) throws customerNotFoundException
{
	System.out.println(""+email); 
	Optional<seller> seller_result=sr_repo.findBySellerEmail(email);
	 if(seller_result.isPresent()) {
		 return seller_result.get();
	 }
	 else
	 {
		 throw new customerNotFoundException("Seller not present");
	 }
}
}

package com.product.Project.cart;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.Project.customer.customerNotFoundException;
import com.product.Project.customer.customer;
import com.product.Project.customer.customerRepository;
import com.product.Project.product.UsernotFoundException;
import com.product.Project.product.productRepository;
import com.product.Project.product.products;

@Service
public class CartService {
	@Autowired
	private CartRepository cart_repo;
	@Autowired
	private customerRepository customer_repo;
	@Autowired
	private productRepository repo;
	
	public customer checkcustomer(Integer id) throws customerNotFoundException
	{
		 Optional<customer> customer_result=customer_repo.findById(id);
		 if(customer_result.isPresent()) {
			 return customer_result.get();
		 }
		 else
		 {
			 throw new customerNotFoundException("customer not present");
		 }
	}
	public products checkproduct(Integer id) throws UsernotFoundException
	{
		 Optional<products> product_result=repo.findById(id);
		 if(product_result.isPresent()) {
			 return product_result.get();
		 }
		 else
		 {
			 throw new UsernotFoundException("product not found");
		 }
		 
	}
	public void savecart(Cart Cart)
	{
		cart_repo.save(Cart);
	}
	public List<Cart> Listall(Integer id)
	{
		return(List<Cart>)cart_repo.findByCustomerCustomerId(id);
	}
	public Cart get(Integer id) throws OutofstockException
	{
		Optional<Cart> result=cart_repo.findById(id);
		 if(result.isPresent()) {
			 return result.get();
		 }
		 else
		 {
			 throw new OutofstockException("cart product not found");
		 }	
	 }
	public void delete(Integer id)
	{
		cart_repo.deleteById(id);
	}

}
